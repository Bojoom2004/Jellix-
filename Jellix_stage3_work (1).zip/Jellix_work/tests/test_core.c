#include "../core/jx.h"
#include "../core/jx_catalog.h"
#include "../core/jx_log.h"
#include "../core/jx_profile.h"
#include <stdio.h>
#include <string.h>
int jx_test_fails=0, jx_test_total=0;
#define fails jx_test_fails
#define total jx_test_total
void jx_test_gfx(void);
#define CHECK(c) do{ total++; if(!(c)){ fails++; printf("FAIL %s:%d  %s\n",__FILE__,__LINE__,#c);} }while(0)
#define B JX_BIT

static void t_cfg(void){
    jx_cfg c; jx_cfg_defaults(&c);
    CHECK(c.ui_sound==1 && c.volume==6);
    const char *txt="volume=3\nbrightness=99\nui_sound=0\nbogus=5\nturbo_hz=abc\nscale_mode=2\r\n#c\nswap_combo=0\n";
    int n=jx_cfg_parse(&c,txt,strlen(txt));
    CHECK(n==3);                       /* volume, ui_sound, scale_mode */
    CHECK(c.volume==3 && c.ui_sound==0 && c.scale_mode==2);
    CHECK(c.brightness==7);            /* 99 вне диапазона: осталось по умолчанию */
    CHECK(c.turbo_hz==15);             /* мусор проигнорирован */
    CHECK(c.swap_combo!=0);            /* 0 недопустимо */
    char buf[512]; size_t k=jx_cfg_write(&c,buf,sizeof buf); CHECK(k>0);
    jx_cfg d; jx_cfg_defaults(&d); jx_cfg_parse(&d,buf,k);
    CHECK(memcmp(&c,&d,sizeof c)==0);  /* round-trip */
    jx_cfg e; jx_cfg_defaults(&e); CHECK(jx_cfg_parse(&e,"\x01\x02\xff garbage",12)==0);
    jx_cfg f; jx_cfg_defaults(&f); CHECK(jx_cfg_parse(&f,"volume=4294967296\n",18)==0); /* переполнение */
    CHECK(jx_cfg_write(&c,buf,10)==0); /* малый буфер */
}
static void t_remap(void){
    jx_remap r; jx_remap_identity(&r);
    CHECK(r.map[JX_A]==JX_A && r.map[JX_VOLUP]==JX_NONE);
    CHECK(jx_remap_assign(&r,JX_VOLUP,JX_L2,0)==-1 || r.map[JX_L2]==JX_L2);
    /* L2 занята своей физической кнопкой: без swap отказ, с swap меняются */
    jx_remap r2; jx_remap_identity(&r2);
    CHECK(jx_remap_assign(&r2,JX_VOLUP,JX_L2,0)==-1);
    CHECK(jx_remap_assign(&r2,JX_VOLUP,JX_L2,1)==0);
    CHECK(r2.map[JX_VOLUP]==JX_L2 && r2.map[JX_L2]==JX_NONE);   /* у соседа осталось прежнее VOLUP-значение */
    r2.turbo=B(JX_A)|B(JX_B);
    char buf[512]; size_t n=jx_remap_write(&r2,buf,sizeof buf); CHECK(n>0);
    jx_remap q; memset(&q,0,sizeof q); jx_remap_identity(&q); jx_remap_parse(&q,buf,n);
    CHECK(memcmp(&q,&r2,sizeof q)==0);
    jx_remap z; jx_remap_identity(&z);
    CHECK(jx_remap_parse(&z,"map.99=1\nmap.3=77\nmap.x=1\nturbo=70000\n",38)==0);
}
static void t_volume_rule(void){
    jx_cfg c; jx_cfg_defaults(&c);
    jx_input in; jx_input_init(&in); jx_input_out o;
    jx_remap r; jx_remap_identity(&r);
    /* лаунчер: VOL всегда меняют громкость */
    jx_input_step(&in,&c,&r,0,B(JX_VOLUP),0,&o); CHECK(o.vol_step==1);
    jx_input_step(&in,&c,&r,0,0,10,&o); CHECK(o.vol_step==0);
    jx_input_step(&in,&c,&r,0,B(JX_VOLDN),20,&o); CHECK(o.vol_step==-1);
    jx_input_step(&in,&c,&r,0,0,30,&o);
    /* игра, VOL не назначены: громкость меняется, игре кнопка не уходит */
    jx_input_step(&in,&c,&r,1,B(JX_VOLUP),40,&o); CHECK(o.vol_step==1 && o.game_mask==0);
    jx_input_step(&in,&c,&r,1,0,50,&o);
    /* игра, VOLUP назначена как R2: игровая кнопка, громкость НЕ меняется */
    jx_remap_assign(&r,JX_R2,JX_NONE,1);               /* освободить R2 физ. */
    CHECK(jx_remap_assign(&r,JX_VOLUP,JX_R2,0)==0);
    jx_input_step(&in,&c,&r,1,B(JX_VOLUP),60,&o);
    CHECK(o.vol_step==0 && o.game_mask==B(JX_R2));
    /* VOLDN остался неназначенным и по-прежнему меняет громкость */
    jx_input_step(&in,&c,&r,1,0,70,&o);
    jx_input_step(&in,&c,&r,1,B(JX_VOLDN),80,&o); CHECK(o.vol_step==-1);
    /* пауза (in_game=0): VOLUP даже назначенная в игре меняет громкость */
    jx_input_step(&in,&c,&r,1,0,90,&o);
    jx_input_step(&in,&c,&r,0,B(JX_VOLUP),100,&o); CHECK(o.vol_step==1);
}
static void t_turbo_swap(void){
    jx_cfg c; jx_cfg_defaults(&c); c.turbo_hz=10;                  /* полупериод 50 мс */
    jx_input in; jx_input_init(&in); jx_input_out o;
    jx_remap r; jx_remap_identity(&r); r.turbo=B(JX_A);
    int on=0,off=0;
    for(uint32_t t=0;t<400;t+=10){ jx_input_step(&in,&c,&r,1,B(JX_A),t,&o); if(o.game_mask&B(JX_A))on++; else off++; }
    CHECK(on>10 && off>10);                                        /* реально мигает */
    jx_input_step(&in,&c,&r,1,0,500,&o); CHECK(o.game_mask==0);
    jx_input_step(&in,&c,&r,1,B(JX_A),510,&o); CHECK(o.game_mask&B(JX_A)); /* первый кадр нажат */
    /* перестановка L/R: SELECT+L1+R1, срабатывает один раз */
    jx_input_init(&in); jx_remap_identity(&r);
    jx_input_step(&in,&c,&r,1,B(JX_SELECT)|B(JX_L1)|B(JX_R1),0,&o); CHECK(o.swap_toggled==1);
    jx_input_step(&in,&c,&r,1,B(JX_SELECT)|B(JX_L1)|B(JX_R1),10,&o); CHECK(o.swap_toggled==0);
    jx_input_step(&in,&c,&r,1,0,20,&o);
    jx_input_step(&in,&c,&r,1,B(JX_L1),30,&o); CHECK(o.game_mask==B(JX_L2));
    jx_input_step(&in,&c,&r,1,B(JX_R2),40,&o); CHECK(o.game_mask==B(JX_R1));
    /* одна кнопка комбинации не включает перестановку */
    jx_input_init(&in);
    jx_input_step(&in,&c,&r,1,B(JX_L1),0,&o); CHECK(o.swap_toggled==0 && o.game_mask==B(JX_L1));
    /* в лаунчере комбинация не действует */
    jx_input_step(&in,&c,&r,0,B(JX_SELECT)|B(JX_L1)|B(JX_R1),0,&o); CHECK(o.swap_toggled==0);
}
static void t_fx(void){
    jx_cfg c; jx_cfg_defaults(&c); jx_fx f; jx_fx_init(&f);
    CHECK(jx_fx_ui_sound(&f,&c,0,1000)==1);
    CHECK(jx_fx_ui_sound(&f,&c,0,1050)==0);                       /* не чаще 120 мс */
    CHECK(jx_fx_ui_sound(&f,&c,0,1130)==1);
    CHECK(jx_fx_ui_sound(&f,&c,1,5000)==0);                       /* в игре никогда */
    c.ui_sound=0; CHECK(jx_fx_ui_sound(&f,&c,0,9000)==0);         /* выключено */
    uint8_t lv=0; c.volume=4;
    jx_fx_volume_changed(&f,&c,0,100); CHECK(jx_fx_indicator(&f,101,&lv)==0); /* вне игры не нужен */
    jx_fx_volume_changed(&f,&c,1,100); CHECK(jx_fx_indicator(&f,101,&lv)==1 && lv==4);
    CHECK(jx_fx_indicator(&f,1599,&lv)==1 && jx_fx_indicator(&f,1600,&lv)==0);
    c.vol_indicator=0; jx_fx_init(&f); jx_fx_volume_changed(&f,&c,1,0); CHECK(jx_fx_indicator(&f,1,&lv)==0);
}
static void t_thumb(void){
    enum{W=320,H=240}; static uint16_t img[W*H], th[JX_THUMB_W*JX_THUMB_MAXH];
    for(int y=0;y<H;y++)for(int x=0;x<W;x++) img[y*W+x]=(x<W/2)?0xF800:0x001F;   /* красный | синий */
    int h; CHECK(jx_thumb_make(img,W,H,W,th,JX_THUMB_W,&h)==0 && h==72);
    CHECK(th[0]==0xF800 && th[JX_THUMB_W-1]==0x001F);
    uint8_t buf[JX_THUMB_HDR+JX_THUMB_W*JX_THUMB_MAXH*2];
    size_t n=jx_thumb_encode(th,JX_THUMB_W,h,buf,sizeof buf);
    CHECK(n==(size_t)JX_THUMB_HDR+JX_THUMB_W*h*2);
    int w2,h2; const uint8_t *px;
    CHECK(jx_thumb_decode(buf,n,&w2,&h2,&px)==0 && w2==96 && h2==72);
    CHECK((px[0]|(px[1]<<8))==0xF800);
    CHECK(jx_thumb_decode(buf,n-1,&w2,&h2,&px)==-1);              /* обрезан */
    buf[0]='X'; CHECK(jx_thumb_decode(buf,n,&w2,&h2,&px)==-1);    /* не та магия */
    buf[0]='J'; buf[5]=0xFF; CHECK(jx_thumb_decode(buf,n,&w2,&h2,&px)==-1); /* нелепая ширина */
    /* усреднение: половина чёрная, половина белая -> серый */
    for(int i=0;i<W*H;i++) img[i]=(i&1)?0xFFFF:0x0000;
    jx_thumb_make(img,W,H,W,th,JX_THUMB_W,&h);
    CHECK(((th[5]>>11)&31)>=14 && ((th[5]>>11)&31)<=17);
    CHECK(jx_thumb_make(img,0,H,W,th,96,&h)==-1);
    jx_thumb_make(img,W,H,W,th,48,&h); CHECK(h==36);              /* другая ширина */
    uint32_t mt[4]={0,50,70,60}; CHECK(jx_thumb_pick_latest(mt,4)==2);
    uint32_t none[2]={0,0}; CHECK(jx_thumb_pick_latest(none,2)==-1);
    /* кадр меньше миниатюры и нестандартный stride */
    static uint16_t small[10*10]; for(int i=0;i<100;i++) small[i]=0x07E0;
    CHECK(jx_thumb_make(small,10,10,10,th,JX_THUMB_W,&h)==0 && th[0]==0x07E0);
}

static void t_catalog(void){
    jx_game storage[4]; jx_catalog c; jx_catalog_init(&c,storage,4);
    jx_game a={0},b={0},d={0}; uint32_t ids[4];
    a.id=1; strcpy(a.title,"Zelda"); strcpy(a.path,"/roms/zelda.nes"); strcpy(a.platform,"NES");
    b.id=2; strcpy(b.title,"Metroid"); strcpy(b.path,"/roms/metroid.nes"); strcpy(b.platform,"NES");
    d.id=3; strcpy(d.title,"Sonic"); strcpy(d.path,"/roms/sonic.md"); strcpy(d.platform,"MegaDrive");
    CHECK(jx_catalog_upsert(&c,&a)==0 && jx_catalog_upsert(&c,&b)==0 && jx_catalog_upsert(&c,&d)==0);
    CHECK(c.count==3 && jx_catalog_find(&c,2)!=0 && jx_catalog_find(&c,99)==0);
    CHECK(jx_catalog_set_flags(&c,2,JX_CAT_FAVORITE,1)==0);
    CHECK((jx_catalog_find(&c,2)->flags&JX_CAT_FAVORITE)!=0);
    CHECK(jx_catalog_mark_played(&c,3,100)==0 && jx_catalog_mark_played(&c,3,200)==0);
    CHECK(jx_catalog_find(&c,3)->play_count==2 && jx_catalog_find(&c,3)->last_played==200);
    jx_catalog_sort(&c,JX_CAT_SORT_NAME); CHECK(strcmp(c.items[0].title,"Metroid")==0);
    jx_catalog_sort(&c,JX_CAT_SORT_RECENT); CHECK(c.items[0].id==3);
    CHECK(jx_catalog_search(&c,"nes",ids,4)==2);
    CHECK(jx_catalog_search(&c,"ELD",ids,4)==1 && ids[0]==1);
    CHECK(jx_catalog_set_flags(&c,1,JX_CAT_HIDDEN,1)==0);
    CHECK(jx_catalog_visible_ids(&c,ids,4)==2);
    CHECK(jx_catalog_search(&c,"",ids,4)==2);
    CHECK(jx_catalog_set_flags(&c,99,JX_CAT_HIDDEN,1)==-1);
    a.id=4; CHECK(jx_catalog_upsert(&c,&a)==0); a.id=5; CHECK(jx_catalog_upsert(&c,&a)==-1);
    a.id=2; strcpy(a.title,"Metroid Prime"); CHECK(jx_catalog_upsert(&c,&a)==0 && c.count==4);
}

static void t_profiles(void){
    jx_profile storage[2]; jx_profiles ps; jx_profile p;
    jx_profiles_init(&ps,storage,2);
    CHECK(ps.count==0 && jx_profiles_active(&ps)==0);
    CHECK(jx_profiles_add_default(&ps,1,"Nintendo", "NES")==0);
    CHECK(jx_profiles_add_default(&ps,2,"Mega Drive", "MD")==0);
    CHECK(ps.count==2 && jx_profiles_find(&ps,1)!=0);
    CHECK(jx_profiles_for_platform(&ps,"nes")==jx_profiles_find_const(&ps,1));
    CHECK(jx_profiles_set_active(&ps,2)==0 && jx_profiles_active(&ps)->id==2);
    CHECK(jx_profiles_set_active(&ps,99)==-1);
    memset(&p,0,sizeof p); p.id=1; strcpy(p.name,"NES custom"); strcpy(p.platform,"NES");
    jx_remap_identity(&p.remap); p.scale_mode=2; p.remap.map[JX_A]=99; p.remap.turbo=0xFFFF;
    CHECK(jx_profiles_upsert(&ps,&p)==0 && ps.count==2);
    CHECK(jx_profiles_find(&ps,1)->scale_mode==2);
    CHECK(jx_profiles_find(&ps,1)->remap.map[JX_A]==JX_NONE);
    CHECK(jx_profiles_find(&ps,1)->remap.turbo==0xFFFF);
    p.id=3; CHECK(jx_profiles_upsert(&ps,&p)==-1);
    CHECK(jx_profiles_add_default(&ps,0,"bad","BAD")==-1);
    CHECK(jx_profiles_add_default(&ps,3,"Full","FULL PLATFORM NAME")==-1);
    jx_profiles_init(&ps,0,8); CHECK(ps.capacity==0 && jx_profiles_add_default(&ps,1,"x","x")==-1);
}

static void t_log(void){
    jx_log l; jx_log_entry e; char msg[100];
    jx_log_init(&l); CHECK(jx_log_count(&l)==0 && jx_log_get(&l,0,&e)==0);
    jx_log_write(&l,JX_LOG_INFO,10,"boot"); jx_log_write(&l,JX_LOG_WARN,20,"battery low");
    CHECK(jx_log_count(&l)==2 && jx_log_get(&l,0,&e)==1);
    CHECK(e.time_ms==20 && e.level==JX_LOG_WARN && strcmp(e.text,"battery low")==0);
    for(int i=0;i<40;i++){ sprintf(msg,"event-%d",i); jx_log_write(&l,JX_LOG_DEBUG,(uint32_t)(30+i),msg); }
    CHECK(jx_log_count(&l)==JX_LOG_CAPACITY && l.dropped==10);
    CHECK(jx_log_get(&l,0,&e)==1 && strcmp(e.text,"event-39")==0);
    CHECK(jx_log_get(&l,31,&e)==1 && strcmp(e.text,"event-8")==0);
    CHECK(jx_log_get(&l,32,&e)==0);
    memset(msg,'x',sizeof msg); msg[sizeof msg-1]='\0'; jx_log_write(&l,JX_LOG_ERROR,99,msg);
    CHECK(jx_log_get(&l,0,&e)==1 && e.text[JX_LOG_TEXT-1]=='\0');
    jx_log_write(&l,99,100,"invalid"); CHECK(l.dropped==11);
}

int main(void){
    t_cfg(); t_remap(); t_volume_rule(); t_turbo_swap(); t_fx(); t_thumb(); t_catalog(); t_profiles(); t_log(); jx_test_gfx();
    printf("%d/%d проверок прошло\n", total-fails, total);
    return fails?1:0;
}
