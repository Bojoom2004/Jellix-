#include "../core/jx_gfx.h"
#include "../core/jx_home.h"
#include <stdio.h>
#include <string.h>
extern int jx_test_total, jx_test_fails;
#define CHECK(c) do{ jx_test_total++; if(!(c)){ jx_test_fails++; printf("FAIL %s:%d  %s\n",__FILE__,__LINE__,#c);} }while(0)

static void put16(uint8_t *p,int v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }

static void t_img(void){
    uint8_t b[12+2*2*2+4]; memset(b,0,sizeof b);
    memcpy(b,"JXI1",4); put16(b+4,2); put16(b+6,2); b[8]=1;
    put16(b+12,0xF800); put16(b+14,0x07E0); put16(b+16,0x001F); put16(b+18,0xFFFF);
    b[20]=255; b[21]=128; b[22]=0; b[23]=255;
    jx_img im; CHECK(jx_img_parse(b,sizeof b,&im)==0 && im.w==2 && im.h==2 && im.a);
    CHECK(jx_img_parse(b,sizeof b-1,&im)==-1);                 /* размер не сходится */
    b[0]='X'; CHECK(jx_img_parse(b,sizeof b,&im)==-1); b[0]='J';
    jx_img_parse(b,sizeof b,&im);
    uint16_t px[4*4]; jx_fb fb={px,4,4,4};
    jx_fill(&fb,0,0,4,4,0x0000);
    jx_blit(&fb,&im,1,1);
    CHECK(px[1*4+1]==0xF800);                                  /* a=255: как есть */
    CHECK(px[1*4+2]!=0x0000 && px[1*4+2]!=0x07E0);             /* a=128: смесь */
    CHECK(px[2*4+1]==0x0000);                                  /* a=0: фон */
    CHECK(px[2*4+2]==0xFFFF);
    /* отсечение: картинка частично и полностью за экраном, без записи за границы */
    jx_fill(&fb,0,0,4,4,0x1234);
    jx_blit(&fb,&im,-1,-1); CHECK(px[0]==0xFFFF);              /* виден только правый нижний пиксель */
    jx_blit(&fb,&im,3,3);   CHECK(px[15]==0xF800);
    jx_blit(&fb,&im,100,100); jx_blit(&fb,&im,-100,-100);      /* не падает */
    jx_fill(&fb,-5,-5,100,100,0xABCD); CHECK(px[0]==0xABCD && px[15]==0xABCD);
    jx_fill(&fb,2,2,0,0,0); CHECK(px[10]==0xABCD);             /* пустой прямоугольник */
}
static void t_mix(void){
    CHECK(jx_mix565(0x0000,0xFFFF,255)==0xFFFF);
    CHECK(jx_mix565(0x1234,0xFFFF,0)==0x1234);
    uint16_t m=jx_mix565(0x0000,0xFFFF,128);
    CHECK(((m>>11)&31)>=15 && ((m>>11)&31)<=16 && ((m>>5)&63)>=31 && ((m>>5)&63)<=32);
    /* монотонность по альфе для каждого канала */
    int ok=1; uint16_t prev=0; for(int a=0;a<=255;a++){ uint16_t v=jx_mix565(0,0xF800,(uint8_t)a); if((v>>11)<(prev>>11)) ok=0; prev=v; }
    CHECK(ok);
}
static void t_font(void){
    /* два знака: 'A' (id 65, ширина 3, advance 4) и '?' (id 63, advance 5); атлас 4x2 */
    uint8_t b[16+2*12+8]; memset(b,0,sizeof b);
    memcpy(b,"JXF1",4); put16(b+4,6); put16(b+6,5); put16(b+8,2); put16(b+10,4); put16(b+12,2);
    uint8_t *c=b+16;
    put16(c,63); put16(c+2,0); put16(c+4,0); c[6]=1; c[7]=2; c[8]=0; c[9]=0; c[10]=5;
    put16(c+12,65); put16(c+14,1); put16(c+16,0); c[18]=3; c[19]=2; c[20]=0; c[21]=0; c[22]=4;
    uint8_t *at=b+16+24; for(int i=0;i<8;i++) at[i]=255;
    jx_font f; CHECK(jx_font_parse(b,sizeof b,&f)==0 && f.n==2);
    CHECK(jx_font_parse(b,sizeof b-1,&f)==-1);
    jx_font_parse(b,sizeof b,&f);
    CHECK(jx_text_width(&f,"A")==4);
    CHECK(jx_text_width(&f,"AA")==8);
    CHECK(jx_text_width(&f,"Z")==5);                  /* нет знака: подставляется '?' */
    CHECK(jx_text_width(&f,"\xD0\x96")==5);           /* кириллица, нет в шрифте: '?' */
    CHECK(jx_text_width(&f,"\xff\xfe")==10);          /* битый UTF-8 не зацикливается */
    CHECK(jx_text_width(&f,"")==0);
    uint16_t px[8*4]; jx_fb fb={px,8,4,8}; jx_fill(&fb,0,0,8,4,0);
    int x=jx_text(&fb,&f,0,0,0xFFFF,"A"); CHECK(x==4 && px[0]==0xFFFF && px[2]==0xFFFF && px[3]==0);  /* ширина глифа 3, advance 4 */
    x=jx_text(&fb,&f,6,3,0xFFFF,"AAAA"); CHECK(x==22);   /* уходит за край, без записи за границы */
}
static void t_home(void){
    jx_home_view v; memset(&v,0,sizeof v); v.count=18;       /* последняя строка неполная: 3 плитки */
    CHECK(jx_home_move(&v,0,1,0)==1);
    CHECK(jx_home_move(&v,0,-1,0)==0);                       /* левый край */
    CHECK(jx_home_move(&v,0,0,-1)==0);                       /* верхний край */
    CHECK(jx_home_move(&v,4,1,0)==4);                        /* правый край */
    CHECK(jx_home_move(&v,2,0,1)==7);
    CHECK(jx_home_move(&v,13,0,1)==17);                      /* строка 3 неполная: берём последнюю */
    CHECK(jx_home_move(&v,17,1,0)==17);                      /* дальше пусто */
    CHECK(jx_home_move(&v,16,1,0)==17);
    v.count=0; CHECK(jx_home_move(&v,0,1,0)==0);
    int x,y; jx_home_slot_pos(0,&x,&y); CHECK(x==89 && y==42);
    jx_home_slot_pos(19,&x,&y); CHECK(x==334 && y==218);
    /* отрисовка с пустыми слотами и без подсветки не падает */
    uint16_t px[480*320]; jx_fb fb={px,480,320,480}; v.count=20; v.bg=0x1111;
    jx_home_draw(&fb,&v,5); CHECK(px[0]==0x1111);
}
void jx_test_gfx(void){ t_img(); t_mix(); t_font(); t_home(); }
