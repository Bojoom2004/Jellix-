/* ПК-симулятор: загружает ресурсы (.jxi/.jxf) из папки так же, как это будет на
 * устройстве (целым файлом в память), рисует экран в RGB565 и пишет PPM. */
#include "../core/jx_gfx.h"
#include "../core/jx_home.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t *slurp(const char *path,size_t *n){
    FILE *f=fopen(path,"rb"); if(!f) return NULL;
    fseek(f,0,SEEK_END); long l=ftell(f); fseek(f,0,SEEK_SET);
    uint8_t *b=malloc((size_t)l); if(fread(b,1,(size_t)l,f)!=(size_t)l){ free(b); fclose(f); return NULL; }
    fclose(f); *n=(size_t)l; return b;
}
static int load_img(const char *dir,const char *name,jx_img *im){
    char p[512]; snprintf(p,sizeof p,"%s/%s.jxi",dir,name);
    size_t n; uint8_t *b=slurp(p,&n); if(!b){ fprintf(stderr,"нет файла %s\n",p); return -1; }
    if(jx_img_parse(b,n,im)){ fprintf(stderr,"плохой формат %s\n",p); return -1; }
    return 0;
}
static void save_ppm(const jx_fb *fb,const char *path){
    FILE *f=fopen(path,"wb"); fprintf(f,"P6\n%d %d\n255\n",fb->w,fb->h);
    for(int y=0;y<fb->h;y++) for(int x=0;x<fb->w;x++){
        uint16_t p=fb->px[(size_t)y*fb->stride+x];
        uint8_t rgb[3]={(uint8_t)(((p>>11)&31)<<3|((p>>11)&31)>>2),(uint8_t)(((p>>5)&63)<<2|((p>>5)&63)>>4),(uint8_t)((p&31)<<3|(p&31)>>2)};
        fwrite(rgb,1,3,f);
    }
    fclose(f);
}

int main(int argc,char **argv){
    if(argc<4){ fprintf(stderr,"использование: sim assets_dir выбор out.ppm\n"); return 2; }
    const char *dir=argv[1]; int sel=atoi(argv[2]);
    static const char *names[]={"ps1","snes","n64","gba","gbc","genesis","nes","mame","atari2600","neogeo",
        "ffvii","super_metroid","zelda_oot","tekken3","metal_slug","chrono_trigger","pokemon_red","smw","settings","add_app"};
    static jx_img tiles[20], glow; static jx_home_view v;
    for(int i=0;i<20;i++){ char n[64]; snprintf(n,sizeof n,"tiles__tile_%s",names[i]); if(load_img(dir,n,&tiles[i])) return 1; v.tile[i]=&tiles[i]; }
    if(load_img(dir,"ui_main__tile_selected_glow_snes",&glow)) return 1;
    v.glow=&glow; v.count=20; v.bg=JX_RGB(6,12,14);
    static uint16_t buf[480*320]; jx_fb fb={buf,480,320,480};
    jx_home_draw(&fb,&v,sel); save_ppm(&fb,argv[3]); return 0;
}
