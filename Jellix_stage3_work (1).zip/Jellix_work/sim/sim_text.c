/* Проверка шрифтов: рисует строки на латинице и кириллице обоими размерами. */
#include "../core/jx_gfx.h"
#include <stdio.h>
#include <stdlib.h>
static uint8_t *slurp(const char *p,size_t *n){ FILE *f=fopen(p,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long l=ftell(f); fseek(f,0,SEEK_SET);
    uint8_t *b=malloc((size_t)l); if(fread(b,1,(size_t)l,f)!=(size_t)l) return NULL; fclose(f); *n=(size_t)l; return b; }
int main(int argc,char **argv){
    if(argc<3) return 2;
    char p[512]; size_t n; jx_font f12,f16;
    snprintf(p,sizeof p,"%s/font_h12.jxf",argv[1]); uint8_t *a=slurp(p,&n); if(!a||jx_font_parse(a,n,&f12)) return 1;
    snprintf(p,sizeof p,"%s/font_h16.jxf",argv[1]); uint8_t *b=slurp(p,&n); if(!b||jx_font_parse(b,n,&f16)) return 1;
    static uint16_t buf[480*120]; jx_fb fb={buf,480,120,480}; jx_fill(&fb,0,0,480,120,JX_RGB(6,12,14));
    const char *L1="Jellix: Game Boy Advance 0123456789";
    const char *L2="Настройки: Звук, Экран, Управление";
    const char *L3="Сохранить  Загрузить  Продолжить игру";
    jx_text(&fb,&f16,8,6,JX_RGB(92,225,184),L1);  jx_text(&fb,&f16,8,32,JX_RGB(255,255,255),L2);
    jx_text(&fb,&f12,8,62,JX_RGB(255,255,255),L1); jx_text(&fb,&f12,8,82,JX_RGB(200,200,200),L2); jx_text(&fb,&f12,8,100,JX_RGB(200,200,200),L3);
    printf("ширина L2 (h16): %d px\n",jx_text_width(&f16,L2));
    FILE *o=fopen(argv[2],"wb"); fprintf(o,"P6\n480 120\n255\n");
    for(int i=0;i<480*120;i++){ uint16_t v=buf[i]; uint8_t rgb[3]={(uint8_t)(((v>>11)&31)<<3),(uint8_t)(((v>>5)&63)<<2),(uint8_t)((v&31)<<3)}; fwrite(rgb,1,3,o);} fclose(o); return 0; }
