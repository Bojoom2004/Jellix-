#!/usr/bin/env python3
"""PNG -> .jxi (RGB565 [+ 8-bit альфа]) и BMFont (.fnt + атлас) -> .jxf.
  png2jxi.py image  in.png out.jxi
  png2jxi.py font   in.fnt out.jxf      (атлас-PNG рядом, берётся из строки page file=)
  png2jxi.py dir    assets_dir out_dir  (все PNG рекурсивно, плоские имена)
Формат JXI1: 'JXI1', u16 w, u16 h, u8 flags(1=есть альфа), u8 0, u16 0 | RGB565 LE | [alpha8]
Формат JXF1: 'JXF1', u16 lineH, u16 base, u16 n, u16 aw, u16 ah, u16 0 |
             n*12: u16 id,u16 x,u16 y,u8 w,u8 h,i8 xoff,i8 yoff,u8 xadv,u8 0 | alpha8 атлас"""
import sys, os, struct, re
from PIL import Image

def rgb565(r,g,b): return ((r>>3)<<11)|((g>>2)<<5)|(b>>3)

def image(src, dst, force_alpha=None):
    im = Image.open(src).convert('RGBA')
    w,h = im.size
    px = im.tobytes()
    has_a = any(px[i] < 255 for i in range(3, len(px), 4)) if force_alpha is None else force_alpha
    out = bytearray(b'JXI1' + struct.pack('<HHBBH', w, h, 1 if has_a else 0, 0, 0))
    for i in range(0, len(px), 4):
        out += struct.pack('<H', rgb565(px[i], px[i+1], px[i+2]))
    if has_a: out += bytes(px[i] for i in range(3, len(px), 4))
    open(dst,'wb').write(out)
    return len(out)

def font(src, dst):
    txt = open(src, encoding='utf-8').read()
    c = re.search(r'lineHeight=(\d+) base=(\d+) scaleW=(\d+) scaleH=(\d+)', txt)
    lh, base, aw, ah = map(int, c.groups())
    page = re.search(r'page id=0 file="([^"]+)"', txt).group(1)
    chars = []
    for m in re.finditer(r'char id=(\d+) x=(\d+) y=(\d+) width=(\d+) height=(\d+) xoffset=(-?\d+) yoffset=(-?\d+) xadvance=(\d+)', txt):
        chars.append(tuple(map(int, m.groups())))
    chars.sort()
    atlas = Image.open(os.path.join(os.path.dirname(src), page)).convert('RGBA')
    assert atlas.size == (aw, ah), (atlas.size, aw, ah)
    out = bytearray(b'JXF1' + struct.pack('<HHHHHH', lh, base, len(chars), aw, ah, 0))
    for (i,x,y,w,h,xo,yo,xa) in chars:
        out += struct.pack('<HHHBBbbBB', i, x, y, w, h, xo, yo, xa, 0)
    raw = atlas.tobytes()
    # в атласе у букв есть тёмная обводка: покрытие = альфа * яркость, обводка выпадает
    out += bytes((raw[k+3] * max(raw[k], raw[k+1], raw[k+2]) + 127) // 255 for k in range(0, aw*ah*4, 4))
    open(dst,'wb').write(out)
    return len(out)

if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'image': print(image(sys.argv[2], sys.argv[3]))
    elif cmd == 'font': print(font(sys.argv[2], sys.argv[3]))
    elif cmd == 'dir':
        src, dst = sys.argv[2], sys.argv[3]; os.makedirs(dst, exist_ok=True); tot = 0; n = 0
        for root,_,files in os.walk(src):
            for f in sorted(files):
                if f.lower().endswith('.png'):
                    rel = os.path.relpath(os.path.join(root,f), src).replace(os.sep,'__')
                    tot += image(os.path.join(root,f), os.path.join(dst, rel[:-4] + '.jxi')); n += 1
        print(n, 'файлов,', tot, 'байт')
