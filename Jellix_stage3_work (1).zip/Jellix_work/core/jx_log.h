#ifndef JX_LOG_H
#define JX_LOG_H
#include <stddef.h>
#include <stdint.h>
#define JX_LOG_CAPACITY 32
#define JX_LOG_TEXT 72
enum { JX_LOG_DEBUG=0, JX_LOG_INFO=1, JX_LOG_WARN=2, JX_LOG_ERROR=3 };
typedef struct { uint32_t time_ms; uint8_t level; char text[JX_LOG_TEXT]; } jx_log_entry;
typedef struct { jx_log_entry entries[JX_LOG_CAPACITY]; uint16_t head; uint16_t count; uint32_t dropped; } jx_log;
void jx_log_init(jx_log *log);
void jx_log_write(jx_log *log, uint8_t level, uint32_t time_ms, const char *message);
size_t jx_log_count(const jx_log *log);
/* Newest-first, offset 0 is most recent. Returns 0 if offset is out of range. */
int jx_log_get(const jx_log *log, size_t offset, jx_log_entry *out);
#endif
