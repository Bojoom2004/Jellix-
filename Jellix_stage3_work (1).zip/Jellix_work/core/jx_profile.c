#include "jx_profile.h"
#include <string.h>

static void copy_text(char *dst, size_t cap, const char *src) {
    size_t n = 0;
    if (!cap) return;
    if (src) while (n + 1 < cap && src[n]) { dst[n] = src[n]; n++; }
    dst[n] = '\0';
}

static int text_eq(const char *a, const char *b) {
    if (!a || !b) return 0;
    while (*a && *b) {
        unsigned char x = (unsigned char)*a++, y = (unsigned char)*b++;
        if (x >= 'A' && x <= 'Z') x = (unsigned char)(x + ('a' - 'A'));
        if (y >= 'A' && y <= 'Z') y = (unsigned char)(y + ('a' - 'A'));
        if (x != y) return 0;
    }
    return *a == *b;
}

void jx_profiles_init(jx_profiles *ps, jx_profile *storage, uint8_t capacity) {
    if (!ps) return;
    ps->items = storage;
    ps->count = 0;
    ps->capacity = storage ? capacity : 0;
    ps->active_id = 0;
}

jx_profile *jx_profiles_find(jx_profiles *ps, uint32_t id) {
    if (!ps || !ps->items || id == 0) return NULL;
    for (uint8_t i = 0; i < ps->count; ++i)
        if (ps->items[i].id == id) return &ps->items[i];
    return NULL;
}

const jx_profile *jx_profiles_find_const(const jx_profiles *ps, uint32_t id) {
    if (!ps || !ps->items || id == 0) return NULL;
    for (uint8_t i = 0; i < ps->count; ++i)
        if (ps->items[i].id == id) return &ps->items[i];
    return NULL;
}

int jx_profiles_upsert(jx_profiles *ps, const jx_profile *profile) {
    if (!ps || !ps->items || !profile || profile->id == 0 ||
        !profile->platform[0]) return -1;
    jx_profile *dst = jx_profiles_find(ps, profile->id);
    if (!dst) {
        if (ps->count >= ps->capacity) return -1;
        dst = &ps->items[ps->count++];
    }
    *dst = *profile;
    dst->name[JX_PROFILE_NAME - 1] = '\0';
    dst->platform[JX_PROFILE_PLATFORM - 1] = '\0';
    if (dst->scale_mode > 2) dst->scale_mode = 0;
    if (dst->rewind > 1) dst->rewind = 0;
    for (unsigned i = 0; i < JX_NBTN; ++i)
        if (dst->remap.map[i] != JX_NONE && dst->remap.map[i] >= JX_NBTN)
            dst->remap.map[i] = JX_NONE;
    dst->remap.turbo &= (uint16_t)((1u << JX_NBTN) - 1u);
    return 0;
}

const jx_profile *jx_profiles_for_platform(const jx_profiles *ps, const char *platform) {
    if (!ps || !ps->items || !platform || !*platform) return NULL;
    for (uint8_t i = 0; i < ps->count; ++i)
        if (text_eq(ps->items[i].platform, platform)) return &ps->items[i];
    return NULL;
}

int jx_profiles_set_active(jx_profiles *ps, uint32_t id) {
    if (!jx_profiles_find(ps, id)) return -1;
    ps->active_id = id;
    return 0;
}

const jx_profile *jx_profiles_active(const jx_profiles *ps) {
    return ps ? jx_profiles_find_const(ps, ps->active_id) : NULL;
}

int jx_profiles_add_default(jx_profiles *ps, uint32_t id, const char *name,
                            const char *platform) {
    jx_profile p;
    if (!ps || !id || !platform || !*platform) return -1;
    memset(&p, 0, sizeof p);
    p.id = id;
    copy_text(p.name, sizeof p.name, name ? name : platform);
    copy_text(p.platform, sizeof p.platform, platform);
    p.scale_mode = 0;
    p.filter = 0;
    p.rewind = 0;
    jx_remap_identity(&p.remap);
    return jx_profiles_upsert(ps, &p);
}
