/* Jellix core: переносимая логика без зависимостей от ОС и железа.
 * Только stdint/stddef. Всё, что касается экрана, кнопок, файлов и звука
 * на устройстве, делает тонкий слой HAL, ядро работает с буферами. */
#ifndef JX_H
#define JX_H
#include <stdint.h>
#include <stddef.h>

/* ---------- кнопки (физические и «игровые» используют один набор бит) ---------- */
enum {
    JX_UP = 0, JX_DOWN, JX_LEFT, JX_RIGHT,
    JX_A, JX_B, JX_X, JX_Y,
    JX_L1, JX_R1, JX_L2, JX_R2,
    JX_START, JX_SELECT, JX_VOLUP, JX_VOLDN,
    JX_NBTN            /* 16 */
};
#define JX_BIT(b) ((uint16_t)(1u << (b)))
#define JX_NONE 0xFF

/* ---------- настройки ---------- */
typedef struct {
    uint8_t  volume;          /* 0..10 */
    uint8_t  brightness;      /* 1..10 */
    uint8_t  ui_sound;        /* звуки интерфейса: только лаунчер и пауза */
    uint8_t  vol_indicator;   /* индикатор громкости в игре */
    uint8_t  show_thumbs;     /* скриншоты сохранений */
    uint8_t  scale_mode;      /* 0 пропорции, 1 весь экран, 2 оригинал */
    uint8_t  filter;          /* 0 нет, 1.. фильтры */
    uint8_t  language;        /* 0 ru, 1 en */
    uint8_t  devmode;
    uint8_t  screenshot;      /* скриншот в игре (глобально) */
    uint8_t  rewind;          /* перемотка (глобально) */
    uint8_t  turbo_hz;        /* частота турбо, 5..30 */
    uint16_t swap_combo;      /* маска комбинации перестановки L1/L2<->R1/R2 */
} jx_cfg;

void jx_cfg_defaults(jx_cfg *c);
/* Разбор текста key=value. Неизвестные ключи игнорируются, значения вне
 * диапазона заменяются значением по умолчанию. Возвращает число принятых ключей.
 * Битый/пустой файл не ломает систему: остаются заводские значения. */
int  jx_cfg_parse(jx_cfg *c, const char *text, size_t len);
/* Запись; возвращает длину или 0, если буфер мал. */
size_t jx_cfg_write(const jx_cfg *c, char *out, size_t cap);

/* ---------- ремап для игры / профиль консоли ---------- */
typedef struct {
    uint8_t  map[JX_NBTN];    /* физическая кнопка -> игровая (JX_NONE = не назначена) */
    uint16_t turbo;           /* маска ИГРОВЫХ кнопок с турбо */
} jx_remap;

void jx_remap_identity(jx_remap *r);
/* Громкость на VOL+/VOL- по умолчанию не назначена в игре (map = JX_NONE). */
int  jx_remap_parse(jx_remap *r, const char *text, size_t len);
size_t jx_remap_write(const jx_remap *r, char *out, size_t cap);
/* Назначить с проверкой конфликта. Возвращает -1, если кнопка занята и swap=0
 * (UI спросит «поменять местами?»), иначе 0. swap=1 меняет местами. */
int  jx_remap_assign(jx_remap *r, uint8_t phys, uint8_t game_btn, int swap);

/* ---------- обработка ввода ---------- */
typedef struct {
    uint16_t prev_raw;
    uint32_t turbo_start[JX_NBTN];
    uint8_t  lr_swapped;      /* L1<->L2, R1<->R2 */
    uint8_t  combo_latched;
} jx_input;

typedef struct {
    uint16_t game_mask;       /* что отдать эмулятору */
    int8_t   vol_step;        /* -1, 0, +1: запрос изменить громкость */
    uint8_t  swap_toggled;    /* сработала комбинация перестановки */
} jx_input_out;

void jx_input_init(jx_input *in);
/* in_game=1: эмулятор запущен (применяется ремап; VOL+/VOL- меняют громкость
 * только если не назначены игровыми). in_game=0: лаунчер/пауза, кнопки как есть,
 * VOL+/VOL- всегда меняют громкость. */
void jx_input_step(jx_input *in, const jx_cfg *cfg, const jx_remap *rm,
                   int in_game, uint16_t raw, uint32_t now_ms, jx_input_out *out);

/* ---------- звук интерфейса и индикатор громкости ---------- */
typedef struct { uint32_t last_ui_snd; uint32_t ind_until; uint8_t ind_level; } jx_fx;
void jx_fx_init(jx_fx *f);
/* 1, если сейчас можно проиграть мягкий звук (только вне игры, не чаще 120 мс). */
int  jx_fx_ui_sound(jx_fx *f, const jx_cfg *c, int in_game, uint32_t now_ms);
/* Громкость реально изменилась кнопкой в игре: включить индикатор на 1.5 с. */
void jx_fx_volume_changed(jx_fx *f, const jx_cfg *c, int in_game, uint32_t now_ms);
/* 1, если индикатор надо рисовать; level -> 0..10. */
int  jx_fx_indicator(const jx_fx *f, uint32_t now_ms, uint8_t *level);

/* ---------- миниатюры сохранений (JTH1) ---------- */
#define JX_THUMB_W 96
#define JX_THUMB_MAXW 160
#define JX_THUMB_MAXH 120
#define JX_THUMB_HDR 8
/* Уменьшение кадра RGB565 (усреднение по блокам). dst: минимум tw*th*2 байт,
 * где th = sh*tw/sw (не меньше 1). Возвращает 0 или -1 при плохих размерах. */
int  jx_thumb_make(const uint16_t *src, int sw, int sh, int stride_px,
                   uint16_t *dst, int tw, int *out_h);
/* Кодирование в формат файла: "JTH1", u16 w, u16 h (LE), пиксели RGB565 LE. */
size_t jx_thumb_encode(const uint16_t *px, int w, int h, uint8_t *out, size_t cap);
/* Проверка и разбор. Возвращает 0 и указатель на пиксели внутри buf, иначе -1. */
int  jx_thumb_decode(const uint8_t *buf, size_t size, int *w, int *h, const uint8_t **px);
/* Индекс самого свежего слота (по времени), -1 если слотов нет. */
int  jx_thumb_pick_latest(const uint32_t *mtimes, int n);

#endif
