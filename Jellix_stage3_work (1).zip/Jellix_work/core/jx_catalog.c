#include "jx_catalog.h"
#include <string.h>

static char lower_ascii(char c) { return (c >= 'A' && c <= 'Z') ? (char)(c + ('a' - 'A')) : c; }
static int cmp_text(const char *a, const char *b) {
    while (*a && *b) { char x=lower_ascii(*a++), y=lower_ascii(*b++); if (x!=y) return x<y?-1:1; }
    return *a ? 1 : (*b ? -1 : 0);
}
static int contains_text(const char *s, const char *q) {
    size_t n=strlen(q); if (!n) return 1;
    for (; *s; ++s) { size_t i=0; while (i<n && s[i] && lower_ascii(s[i])==lower_ascii(q[i])) ++i; if (i==n) return 1; }
    return 0;
}
void jx_catalog_init(jx_catalog *c, jx_game *storage, uint16_t cap) {
    if (!c) return;
    c->items=storage; c->count=0; c->capacity=storage?cap:0;
}
jx_game *jx_catalog_find(jx_catalog *c, uint32_t id) {
    uint16_t i; if (!c || !c->items) return 0;
    for (i=0;i<c->count;i++) { if (c->items[i].id==id) return &c->items[i]; }
    return 0;
}
const jx_game *jx_catalog_find_const(const jx_catalog *c, uint32_t id) {
    uint16_t i; if (!c || !c->items) return 0;
    for (i=0;i<c->count;i++) { if (c->items[i].id==id) return &c->items[i]; }
    return 0;
}
int jx_catalog_upsert(jx_catalog *c, const jx_game *g) {
    jx_game *old; if (!c || !c->items || !g || !g->id) return -1;
    old=jx_catalog_find(c,g->id);
    if (old) { *old=*g; old->title[JX_CAT_MAX_TITLE-1]=0; old->path[JX_CAT_MAX_PATH-1]=0; old->platform[JX_CAT_MAX_PLATFORM-1]=0; return 0; }
    if (c->count>=c->capacity) return -1;
    c->items[c->count]=*g;
    c->items[c->count].title[JX_CAT_MAX_TITLE-1]=0;
    c->items[c->count].path[JX_CAT_MAX_PATH-1]=0;
    c->items[c->count].platform[JX_CAT_MAX_PLATFORM-1]=0;
    c->count++; return 0;
}
int jx_catalog_set_flags(jx_catalog *c, uint32_t id, uint16_t mask, int enabled) {
    jx_game *g=jx_catalog_find(c,id); if (!g) return -1;
    if (enabled) g->flags|=mask; else g->flags=(uint16_t)(g->flags & (uint16_t)~mask); return 0;
}
int jx_catalog_mark_played(jx_catalog *c, uint32_t id, uint32_t ts) {
    jx_game *g=jx_catalog_find(c,id); if (!g) return -1;
    g->last_played=ts; if (g->play_count!=UINT16_MAX) ++g->play_count; return 0;
}
static int before(const jx_game *a,const jx_game *b,uint8_t mode) {
    int v;
    if (mode==JX_CAT_SORT_RECENT) { if (a->last_played!=b->last_played) return a->last_played>b->last_played; }
    else if (mode==JX_CAT_SORT_PLATFORM) { v=cmp_text(a->platform,b->platform); if(v) return v<0; }
    v=cmp_text(a->title,b->title); if(v) return v<0; return a->id<b->id;
}
void jx_catalog_sort(jx_catalog *c,uint8_t mode) {
    uint16_t i,j; if(!c || !c->items || mode>JX_CAT_SORT_PLATFORM) return;
    /* Stable insertion sort: bounded and appropriate for handheld-sized catalogs. */
    for(i=1;i<c->count;i++){ jx_game key=c->items[i]; j=i; while(j>0 && before(&key,&c->items[j-1],mode)){ c->items[j]=c->items[j-1]; --j; } c->items[j]=key; }
}
size_t jx_catalog_search(const jx_catalog *c,const char *q,uint32_t *out,size_t cap) {
    uint16_t i; size_t n=0; if(!c || !c->items || !q) return 0;
    for(i=0;i<c->count;i++){ const jx_game *g=&c->items[i]; if((g->flags&JX_CAT_HIDDEN)==0 && (contains_text(g->title,q)||contains_text(g->platform,q))){ if(out && n<cap) out[n]=g->id; ++n; } }
    return n;
}
size_t jx_catalog_visible_ids(const jx_catalog *c,uint32_t *out,size_t cap) {
    uint16_t i; size_t n=0; if(!c || !c->items) return 0;
    for(i=0;i<c->count;i++) {
        if(!(c->items[i].flags&JX_CAT_HIDDEN)){ if(out&&n<cap) out[n]=c->items[i].id; ++n; }
    }
    return n;
}
