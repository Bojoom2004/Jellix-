#ifndef JX_CATALOG_H
#define JX_CATALOG_H
#include <stddef.h>
#include <stdint.h>

/* Bounded, allocation-free game catalog. The caller owns the record array. */
#define JX_CAT_MAX_TITLE 48
#define JX_CAT_MAX_PATH  160
#define JX_CAT_MAX_PLATFORM 12

enum { JX_CAT_FAVORITE = 1u << 0, JX_CAT_HIDDEN = 1u << 1 };
enum { JX_CAT_SORT_NAME = 0, JX_CAT_SORT_RECENT = 1, JX_CAT_SORT_PLATFORM = 2 };

typedef struct {
    uint32_t id;                 /* stable ID supplied by scanner */
    uint32_t last_played;        /* monotonic/RTC seconds; 0 = never */
    uint16_t flags;
    uint16_t play_count;
    char title[JX_CAT_MAX_TITLE];
    char path[JX_CAT_MAX_PATH];
    char platform[JX_CAT_MAX_PLATFORM];
} jx_game;

typedef struct {
    jx_game *items;
    uint16_t count;
    uint16_t capacity;
} jx_catalog;

/* Initialize a catalog over caller-owned storage. */
void jx_catalog_init(jx_catalog *cat, jx_game *storage, uint16_t capacity);
/* Insert or replace by id. Returns 0 on success, -1 on invalid/full. */
int jx_catalog_upsert(jx_catalog *cat, const jx_game *game);
/* Find mutable/const record by stable id; NULL if absent. */
jx_game *jx_catalog_find(jx_catalog *cat, uint32_t id);
const jx_game *jx_catalog_find_const(const jx_catalog *cat, uint32_t id);
/* Set/clear a flag mask. Returns -1 if id is unknown. */
int jx_catalog_set_flags(jx_catalog *cat, uint32_t id, uint16_t mask, int enabled);
/* Record a launch. Saturates play_count at UINT16_MAX. */
int jx_catalog_mark_played(jx_catalog *cat, uint32_t id, uint32_t timestamp);
/* Stable in-place sort by title/platform or descending last-played. */
void jx_catalog_sort(jx_catalog *cat, uint8_t mode);
/* Case-insensitive ASCII substring search; returns total matches, writes up to cap IDs. */
size_t jx_catalog_search(const jx_catalog *cat, const char *query,
                         uint32_t *out_ids, size_t cap);
/* Copy visible records' IDs to output in current storage order. */
size_t jx_catalog_visible_ids(const jx_catalog *cat, uint32_t *out_ids, size_t cap);

#endif
