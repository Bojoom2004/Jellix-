#ifndef JX_UTIL_H
#define JX_UTIL_H
#include <stdint.h>
#include <stddef.h>
/* Мини-функции вместо libc: ядру не нужен ни printf, ни strtol. */
static inline int jx_isdig(char c){ return c>='0'&&c<='9'; }
/* Разбор целого (десятичного, без знака). Возвращает 1 при успехе. */
static inline int jx_atou(const char *s, const char *e, uint32_t *v){
    uint32_t x=0; if(s>=e) return 0;
    for(;s<e;s++){ if(!jx_isdig(*s)) return 0; uint32_t d=(uint32_t)(*s-'0'); if(x>429496729u || (x==429496729u && d>5u)) return 0; x=x*10u+d; }
    *v=x; return 1;
}
/* Запись целого в буфер; возвращает число символов. */
static inline size_t jx_utoa(uint32_t v, char *o){
    char t[11]; int n=0; size_t k=0;
    do{ t[n++]=(char)('0'+v%10u); v/=10u; }while(v);
    while(n) o[k++]=t[--n];
    return k;
}
static inline int jx_keyeq(const char *a, size_t al, const char *lit){
    size_t i=0; while(i<al && lit[i] && a[i]==lit[i]) i++;
    return i==al && lit[i]==0;
}
#endif
