/* Jellix gfx: отрисовка в буфер RGB565. Без ОС и без malloc: всё работает
 * поверх буферов, которые даёт вызывающий (на устройстве это кадровый буфер
 * и ресурсы, прочитанные с флэша). */
#ifndef JX_GFX_H
#define JX_GFX_H
#include <stdint.h>
#include <stddef.h>

typedef struct { uint16_t *px; int w, h, stride; } jx_fb;           /* stride в пикселях */
typedef struct { int w, h; const uint8_t *px; const uint8_t *a; } jx_img; /* px: RGB565 LE (выровнен по 2) */
typedef struct {
    int line_h, base, n, aw, ah;
    const uint8_t *chars;   /* n * 12 байт */
    const uint8_t *atlas;   /* alpha8, aw*ah */
} jx_font;

#define JX_RGB(r,g,b) ((uint16_t)((((r)>>3)<<11)|(((g)>>2)<<5)|((b)>>3)))

/* Разбор ресурсов (формат tools/png2jxi.py). 0 = успех, -1 = неверные данные. */
int  jx_img_parse(const uint8_t *buf, size_t size, jx_img *out);
int  jx_font_parse(const uint8_t *buf, size_t size, jx_font *out);

void jx_fill(jx_fb *fb, int x, int y, int w, int h, uint16_t c);
/* Копирование с отсечением по краям; если у картинки есть альфа, смешивание. */
void jx_blit(jx_fb *fb, const jx_img *im, int x, int y);
/* Текст UTF-8, цвет c, позиция — верхний левый угол строки. Возвращает x после последнего знака. */
int  jx_text(jx_fb *fb, const jx_font *f, int x, int y, uint16_t c, const char *utf8);
int  jx_text_width(const jx_font *f, const char *utf8);
/* Смешивание двух RGB565 по альфе 0..255. */
uint16_t jx_mix565(uint16_t dst, uint16_t src, uint8_t a);

#endif
