#include "jx_log.h"
#include <string.h>
void jx_log_init(jx_log *l) { if(l) memset(l,0,sizeof *l); }
void jx_log_write(jx_log *l,uint8_t level,uint32_t ms,const char *msg) {
    uint16_t slot; size_t i=0; jx_log_entry *e;
    if(!l || !msg || level>JX_LOG_ERROR) return;
    slot=l->head;
    if(l->count==JX_LOG_CAPACITY) l->dropped++;
    else l->count++;
    e=&l->entries[slot]; e->time_ms=ms; e->level=level;
    while(i<JX_LOG_TEXT-1 && msg[i]) { e->text[i]=msg[i]; ++i; } e->text[i]='\0';
    l->head=(uint16_t)((slot+1)%JX_LOG_CAPACITY);
}
size_t jx_log_count(const jx_log *l) { return l?l->count:0; }
int jx_log_get(const jx_log *l,size_t off,jx_log_entry *out) {
    uint16_t idx; if(!l || !out || off>=l->count) return 0;
    idx=(uint16_t)((l->head+JX_LOG_CAPACITY-1-off)%JX_LOG_CAPACITY); *out=l->entries[idx]; return 1;
}
