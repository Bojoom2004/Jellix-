#include "jx.h"
#include "jx_util.h"
#include <string.h>

void jx_cfg_defaults(jx_cfg *c){
    memset(c,0,sizeof *c);
    c->volume=6; c->brightness=7;
    c->ui_sound=1; c->vol_indicator=1; c->show_thumbs=1;
    c->turbo_hz=15;
    /* По умолчанию: SELECT + L1 + R1 одновременно (случайно не нажать). */
    c->swap_combo = JX_BIT(JX_SELECT)|JX_BIT(JX_L1)|JX_BIT(JX_R1);
}

typedef struct { const char *k; size_t off; uint8_t size; uint32_t lo, hi; } fld;
#define F8(n,lo,hi)  { #n, offsetof(jx_cfg,n), 1, lo, hi }
#define F16(n,lo,hi) { #n, offsetof(jx_cfg,n), 2, lo, hi }
static const fld FIELDS[] = {
    F8(volume,0,10), F8(brightness,1,10),
    F8(ui_sound,0,1), F8(vol_indicator,0,1), F8(show_thumbs,0,1),
    F8(scale_mode,0,2), F8(filter,0,7), F8(language,0,1),
    F8(devmode,0,1), F8(screenshot,0,1), F8(rewind,0,1),
    F8(turbo_hz,5,30), F16(swap_combo,1,0xFFFF),
};
#define NF (sizeof FIELDS/sizeof FIELDS[0])

int jx_cfg_parse(jx_cfg *c, const char *t, size_t len){
    int ok=0; const char *p=t, *end=t+len;
    while(p<end){
        const char *ls=p; while(p<end && *p!='\n') p++;
        const char *le=p; if(p<end) p++;
        if(le>ls && le[-1]=='\r') le--;
        if(ls>=le || *ls=='#') continue;
        const char *eq=ls; while(eq<le && *eq!='=') eq++;
        if(eq==le) continue;
        uint32_t v;
        if(!jx_atou(eq+1,le,&v)) continue;
        for(size_t i=0;i<NF;i++){
            if(!jx_keyeq(ls,(size_t)(eq-ls),FIELDS[i].k)) continue;
            if(v<FIELDS[i].lo || v>FIELDS[i].hi) break;      /* вне диапазона: оставить текущее */
            uint8_t *d=(uint8_t*)c+FIELDS[i].off;
            if(FIELDS[i].size==1) *d=(uint8_t)v;
            else { uint16_t w=(uint16_t)v; memcpy(d,&w,2); }
            ok++; break;
        }
    }
    return ok;
}

size_t jx_cfg_write(const jx_cfg *c, char *out, size_t cap){
    size_t n=0;
    for(size_t i=0;i<NF;i++){
        size_t kl=strlen(FIELDS[i].k);
        if(n+kl+1+5+1>cap) return 0;
        memcpy(out+n,FIELDS[i].k,kl); n+=kl; out[n++]='=';
        const uint8_t *s=(const uint8_t*)c+FIELDS[i].off;
        uint32_t v; if(FIELDS[i].size==1) v=*s; else { uint16_t w; memcpy(&w,s,2); v=w; }
        n+=jx_utoa(v,out+n); out[n++]='\n';
    }
    return n;
}
