#ifndef JX_PROFILE_H
#define JX_PROFILE_H
#include "jx.h"

#define JX_PROFILE_CAP 16
#define JX_PROFILE_NAME 24
#define JX_PROFILE_PLATFORM 12

typedef struct {
    uint32_t id;
    uint8_t scale_mode; /* 0 aspect, 1 stretch, 2 original */
    uint8_t filter;     /* renderer-defined filter index */
    uint8_t rewind;     /* 0/1 */
    uint8_t reserved;
    char name[JX_PROFILE_NAME];
    char platform[JX_PROFILE_PLATFORM];
    jx_remap remap;
} jx_profile;

typedef struct {
    jx_profile *items; /* caller-owned fixed storage */
    uint8_t count;
    uint8_t capacity;
    uint32_t active_id;
} jx_profiles;

void jx_profiles_init(jx_profiles *ps, jx_profile *storage, uint8_t capacity);
/* Add or replace by id. Strings are safely truncated and always terminated. */
int jx_profiles_upsert(jx_profiles *ps, const jx_profile *profile);
jx_profile *jx_profiles_find(jx_profiles *ps, uint32_t id);
const jx_profile *jx_profiles_find_const(const jx_profiles *ps, uint32_t id);
/* Select exact platform match (ASCII case-insensitive); returns profile or NULL. */
const jx_profile *jx_profiles_for_platform(const jx_profiles *ps, const char *platform);
int jx_profiles_set_active(jx_profiles *ps, uint32_t id);
const jx_profile *jx_profiles_active(const jx_profiles *ps);
/* Create a safe default profile for a platform and insert it. */
int jx_profiles_add_default(jx_profiles *ps, uint32_t id, const char *name,
                            const char *platform);
#endif
