#include "jx.h"
#include "jx_util.h"
#include <string.h>

/* ---------- ремап ---------- */
void jx_remap_identity(jx_remap *r){
    for(int i=0;i<JX_NBTN;i++) r->map[i]=(uint8_t)i;
    r->map[JX_VOLUP]=JX_NONE; r->map[JX_VOLDN]=JX_NONE;   /* громкость по умолчанию */
    r->turbo=0;
}

int jx_remap_parse(jx_remap *r, const char *t, size_t len){
    int ok=0; const char *p=t,*end=t+len;
    while(p<end){
        const char *ls=p; while(p<end&&*p!='\n')p++;
        const char *le=p; if(p<end)p++;
        if(le>ls&&le[-1]=='\r')le--;
        if(ls>=le||*ls=='#')continue;
        const char *eq=ls; while(eq<le&&*eq!='=')eq++;
        if(eq==le)continue;
        uint32_t v; size_t kl=(size_t)(eq-ls);
        if(kl>4 && ls[0]=='m'&&ls[1]=='a'&&ls[2]=='p'&&ls[3]=='.'){
            uint32_t ph;
            if(!jx_atou(ls+4,eq,&ph)||ph>=JX_NBTN) continue;
            if(eq+1<le && eq[1]=='-' && le-(eq+1)==1){ r->map[ph]=JX_NONE; ok++; continue; }
            if(!jx_atou(eq+1,le,&v)||v>=JX_NBTN) continue;
            r->map[ph]=(uint8_t)v; ok++;
        } else if(jx_keyeq(ls,kl,"turbo")){
            if(jx_atou(eq+1,le,&v)&&v<=0xFFFF){ r->turbo=(uint16_t)v; ok++; }
        }
    }
    return ok;
}

size_t jx_remap_write(const jx_remap *r, char *out, size_t cap){
    size_t n=0;
    for(int i=0;i<JX_NBTN;i++){
        if(n+16>cap) return 0;
        memcpy(out+n,"map.",4); n+=4;
        n+=jx_utoa((uint32_t)i,out+n); out[n++]='=';
        if(r->map[i]==JX_NONE) out[n++]='-'; else n+=jx_utoa(r->map[i],out+n);
        out[n++]='\n';
    }
    if(n+16>cap) return 0;
    memcpy(out+n,"turbo=",6); n+=6; n+=jx_utoa(r->turbo,out+n); out[n++]='\n';
    return n;
}

int jx_remap_assign(jx_remap *r, uint8_t phys, uint8_t g, int swap){
    if(phys>=JX_NBTN) return -1;
    if(g!=JX_NONE){
        for(int i=0;i<JX_NBTN;i++){
            if(i!=phys && r->map[i]==g){
                if(!swap) return -1;               /* спросить «поменять местами?» */
                r->map[i]=r->map[phys];            /* у соседа остаётся то, что было у нас */
                break;
            }
        }
    }
    r->map[phys]=g;
    return 0;
}

/* ---------- ввод ---------- */
void jx_input_init(jx_input *in){ memset(in,0,sizeof *in); }

static uint16_t swap_lr(uint16_t m){
    uint16_t o=m & (uint16_t)~(JX_BIT(JX_L1)|JX_BIT(JX_L2)|JX_BIT(JX_R1)|JX_BIT(JX_R2));
    if(m&JX_BIT(JX_L1)) o|=JX_BIT(JX_L2);
    if(m&JX_BIT(JX_L2)) o|=JX_BIT(JX_L1);
    if(m&JX_BIT(JX_R1)) o|=JX_BIT(JX_R2);
    if(m&JX_BIT(JX_R2)) o|=JX_BIT(JX_R1);
    return o;
}

void jx_input_step(jx_input *in, const jx_cfg *cfg, const jx_remap *rm,
                   int in_game, uint16_t raw, uint32_t now, jx_input_out *out){
    uint16_t pressed = (uint16_t)(raw & ~in->prev_raw);
    out->vol_step=0; out->swap_toggled=0; out->game_mask=0;

    /* комбинация перестановки: срабатывает один раз, пока удерживается */
    uint16_t cb=cfg->swap_combo;
    if(in_game && cb && (raw&cb)==cb){
        if(!in->combo_latched && (pressed&cb)){ in->lr_swapped^=1; out->swap_toggled=1; }
        in->combo_latched=1;
    } else if((raw&cb)!=cb) in->combo_latched=0;

    if(!in_game){
        /* лаунчер/пауза: кнопки как есть, громкость на VOL всегда */
        out->game_mask=(uint16_t)(raw & ~(JX_BIT(JX_VOLUP)|JX_BIT(JX_VOLDN)));
        if(pressed&JX_BIT(JX_VOLUP)) out->vol_step=1;
        else if(pressed&JX_BIT(JX_VOLDN)) out->vol_step=-1;
        in->prev_raw=raw; return;
    }

    uint16_t gm=0;
    for(int p=0;p<JX_NBTN;p++){
        uint8_t g=rm->map[p];
        int down=(raw>>p)&1, was=(in->prev_raw>>p)&1;
        if(g==JX_NONE){
            /* не назначена: VOL меняют громкость, остальные игнорируются */
            if(p==JX_VOLUP && down && !was) out->vol_step=1;
            if(p==JX_VOLDN && down && !was) out->vol_step=-1;
            continue;
        }
        if(!down) continue;
        if(!was) in->turbo_start[p]=now;
        if((rm->turbo>>g)&1){
            uint32_t half = 500u/(cfg->turbo_hz?cfg->turbo_hz:15u);  /* полупериод, мс */
            if(half==0) half=1;
            if(((now-in->turbo_start[p])/half)%2==0) gm|=JX_BIT(g);
        } else gm|=JX_BIT(g);
    }
    if(in->lr_swapped) gm=swap_lr(gm);
    out->game_mask=gm;
    in->prev_raw=raw;
}

/* ---------- эффекты ---------- */
void jx_fx_init(jx_fx *f){ memset(f,0,sizeof *f); f->last_ui_snd=0xFFFFFFFFu; }

int jx_fx_ui_sound(jx_fx *f, const jx_cfg *c, int in_game, uint32_t now){
    if(!c->ui_sound || in_game) return 0;
    if(f->last_ui_snd!=0xFFFFFFFFu && (uint32_t)(now-f->last_ui_snd)<120u) return 0;
    f->last_ui_snd=now; return 1;
}
void jx_fx_volume_changed(jx_fx *f, const jx_cfg *c, int in_game, uint32_t now){
    if(!in_game || !c->vol_indicator) return;
    f->ind_until=now+1500u; f->ind_level=c->volume;
}
int jx_fx_indicator(const jx_fx *f, uint32_t now, uint8_t *level){
    if(f->ind_until==0 || (int32_t)(now-f->ind_until)>=0) return 0;
    if(level) *level=f->ind_level;
    return 1;
}
