#include "jx_gfx.h"

static inline uint16_t rd16(const uint8_t *p){ return (uint16_t)(p[0] | (p[1] << 8)); }

int jx_img_parse(const uint8_t *b, size_t size, jx_img *o){
    if(size<12 || b[0]!='J'||b[1]!='X'||b[2]!='I'||b[3]!='1') return -1;
    int w=rd16(b+4), h=rd16(b+6), fl=b[8];
    if(w<=0||h<=0) return -1;
    size_t need=12+(size_t)w*h*2+((fl&1)?(size_t)w*h:0);
    if(size!=need) return -1;
    o->w=w; o->h=h; o->px=b+12; o->a=(fl&1)?b+12+(size_t)w*h*2:NULL;
    return 0;
}

int jx_font_parse(const uint8_t *b, size_t size, jx_font *f){
    if(size<16 || b[0]!='J'||b[1]!='X'||b[2]!='F'||b[3]!='1') return -1;
    f->line_h=rd16(b+4); f->base=rd16(b+6); f->n=rd16(b+8); f->aw=rd16(b+10); f->ah=rd16(b+12);
    size_t need=16+(size_t)f->n*12+(size_t)f->aw*f->ah;
    if(f->n<=0||size!=need) return -1;
    f->chars=b+16; f->atlas=b+16+(size_t)f->n*12;
    return 0;
}

uint16_t jx_mix565(uint16_t d, uint16_t s, uint8_t a){
    uint32_t dr=(d>>11)&31, dg=(d>>5)&63, db=d&31;
    uint32_t sr=(s>>11)&31, sg=(s>>5)&63, sb=s&31;
    uint32_t ia=255u-a;
    uint32_t tr=sr*a+dr*ia+128u, tg=sg*a+dg*ia+128u, tb=sb*a+db*ia+128u;   /* деление на 255 без div */
    uint32_t r=(tr+(tr>>8))>>8, g=(tg+(tg>>8))>>8, bl=(tb+(tb>>8))>>8;
    return (uint16_t)((r<<11)|(g<<5)|bl);
}

void jx_fill(jx_fb *fb,int x,int y,int w,int h,uint16_t c){
    int x0=x<0?0:x, y0=y<0?0:y, x1=x+w>fb->w?fb->w:x+w, y1=y+h>fb->h?fb->h:y+h;
    for(int yy=y0;yy<y1;yy++){ uint16_t *r=fb->px+(size_t)yy*fb->stride; for(int xx=x0;xx<x1;xx++) r[xx]=c; }
}

void jx_blit(jx_fb *fb,const jx_img *im,int x,int y){
    int x0=x<0?0:x, y0=y<0?0:y, x1=x+im->w>fb->w?fb->w:x+im->w, y1=y+im->h>fb->h?fb->h:y+im->h;
    for(int yy=y0;yy<y1;yy++){
        uint16_t *d=fb->px+(size_t)yy*fb->stride;
        size_t so=(size_t)(yy-y)*im->w;
        for(int xx=x0;xx<x1;xx++){
            size_t i=so+(size_t)(xx-x);
            uint16_t s=rd16(im->px+2*i);
            if(!im->a) d[xx]=s;
            else { uint8_t a=im->a[i]; if(a==255) d[xx]=s; else if(a) d[xx]=jx_mix565(d[xx],s,a); }
        }
    }
}

static int utf8_next(const char **p){
    const unsigned char *s=(const unsigned char*)*p; int c=s[0];
    if(c==0) return 0;
    if(c<0x80){ *p+=1; return c; }
    if((c&0xE0)==0xC0 && (s[1]&0xC0)==0x80){ *p+=2; return ((c&0x1F)<<6)|(s[1]&0x3F); }
    if((c&0xF0)==0xE0 && (s[1]&0xC0)==0x80 && (s[2]&0xC0)==0x80){ *p+=3; return ((c&0x0F)<<12)|((s[1]&0x3F)<<6)|(s[2]&0x3F); }
    *p+=1; return '?';
}
static const uint8_t *glyph(const jx_font *f,int id){
    int lo=0, hi=f->n-1;
    while(lo<=hi){ int m=(lo+hi)/2; const uint8_t *g=f->chars+m*12; int gid=rd16(g);
        if(gid==id) return g;
        if(gid<id) lo=m+1; else hi=m-1; }
    return NULL;
}
int jx_text_width(const jx_font *f,const char *s){
    int w=0, c;
    while((c=utf8_next(&s))){ const uint8_t *g=glyph(f,c); if(!g) g=glyph(f,'?'); if(g) w+=g[10]; }
    return w;
}
int jx_text(jx_fb *fb,const jx_font *f,int x,int y,uint16_t col,const char *s){
    int c;
    while((c=utf8_next(&s))){
        const uint8_t *g=glyph(f,c); if(!g) g=glyph(f,'?'); if(!g) continue;
        int gx=rd16(g+2), gy=rd16(g+4), gw=g[6], gh=g[7], xo=(int8_t)g[8], yo=(int8_t)g[9], xa=g[10];
        for(int j=0;j<gh;j++){
            int py=y+yo+j; if(py<0||py>=fb->h) continue;
            uint16_t *d=fb->px+(size_t)py*fb->stride;
            for(int i=0;i<gw;i++){
                int px=x+xo+i; if(px<0||px>=fb->w) continue;
                uint8_t a=f->atlas[(size_t)(gy+j)*f->aw+gx+i];
                if(a==255) d[px]=col; else if(a) d[px]=jx_mix565(d[px],col,a);
            }
        }
        x+=xa;
    }
    return x;
}
