#ifndef JX_HOME_H
#define JX_HOME_H
#include "jx_gfx.h"
#define JX_HOME_COLS 5
#define JX_HOME_ROWS 4
#define JX_HOME_SLOTS (JX_HOME_COLS*JX_HOME_ROWS)

typedef struct {
    const jx_img *tile[JX_HOME_SLOTS];   /* плитка 57x58 с подписью; NULL = пустой слот */
    int count;                           /* сколько слотов занято (подряд с 0) */
    const jx_img *glow;                  /* подсветка выбранной плитки */
    uint16_t bg;                         /* цвет фона */
} jx_home_view;

/* Перемещение выбора: dx,dy = -1/0/1. Пустые слоты пропускаются. Возвращает новый индекс. */
int  jx_home_move(const jx_home_view *v, int sel, int dx, int dy);
void jx_home_draw(jx_fb *fb, const jx_home_view *v, int sel);
void jx_home_slot_pos(int idx, int *x, int *y);
#endif
