#include "jx_home.h"

/* Координаты сняты с эталонного макета 480x320 (preview_main_480x320.png):
 * шаг 61–62 по горизонтали и 58–60 по вертикали (в макете неровный), поэтому таблицы. */
static const int COL_X[JX_HOME_COLS]={89,150,212,273,334};
static const int ROW_Y[JX_HOME_ROWS]={42,100,158,218};
static const int GLOW_DX=-5, GLOW_DY=-4;

void jx_home_slot_pos(int i,int *x,int *y){
    *x=COL_X[i%JX_HOME_COLS]; *y=ROW_Y[i/JX_HOME_COLS];
}

int jx_home_move(const jx_home_view *v,int sel,int dx,int dy){
    if(v->count<=0) return 0;
    int c=sel%JX_HOME_COLS, r=sel/JX_HOME_COLS;
    int nc=c+dx, nr=r+dy;
    if(nc<0||nc>=JX_HOME_COLS||nr<0||nr>=JX_HOME_ROWS) return sel;     /* край: выбор остаётся */
    int n=nr*JX_HOME_COLS+nc;
    if(n>=v->count){
        /* в строке нет такого столбца: взять последний занятый слот строки, если он есть */
        int last=v->count-1;
        if(last/JX_HOME_COLS==nr && dy!=0) return last;
        return sel;
    }
    return n;
}

void jx_home_draw(jx_fb *fb,const jx_home_view *v,int sel){
    jx_fill(fb,0,0,fb->w,fb->h,v->bg);
    if(v->glow && sel>=0 && sel<v->count){            /* подсветка под плитками */
        int x,y; jx_home_slot_pos(sel,&x,&y);
        jx_blit(fb,v->glow,x+GLOW_DX,y+GLOW_DY);
    }
    for(int i=0;i<v->count && i<JX_HOME_SLOTS;i++){
        if(!v->tile[i]) continue;
        int x,y; jx_home_slot_pos(i,&x,&y);
        jx_blit(fb,v->tile[i],x,y);
    }
}
