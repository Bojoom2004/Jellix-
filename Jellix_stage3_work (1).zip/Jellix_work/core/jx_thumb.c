#include "jx.h"
#include <string.h>

int jx_thumb_make(const uint16_t *src,int sw,int sh,int stride,uint16_t *dst,int tw,int *out_h){
    if(!src||!dst||sw<=0||sh<=0||tw<=0||tw>JX_THUMB_MAXW||stride<sw) return -1;
    int th=(int)((int64_t)sh*tw/sw); if(th<1) th=1;
    if(th>JX_THUMB_MAXH) return -1;
    for(int y=0;y<th;y++){
        int y0=(int)((int64_t)y*sh/th), y1=(int)((int64_t)(y+1)*sh/th); if(y1<=y0) y1=y0+1;
        for(int x=0;x<tw;x++){
            int x0=(int)((int64_t)x*sw/tw), x1=(int)((int64_t)(x+1)*sw/tw); if(x1<=x0) x1=x0+1;
            uint32_t r=0,g=0,b=0,n=0;
            for(int yy=y0;yy<y1;yy++){
                const uint16_t *row=src+(size_t)yy*(size_t)stride;
                for(int xx=x0;xx<x1;xx++){
                    uint16_t p=row[xx];
                    r+=(p>>11)&31u; g+=(p>>5)&63u; b+=p&31u; n++;
                }
            }
            dst[y*tw+x]=(uint16_t)(((r/n)<<11)|((g/n)<<5)|(b/n));
        }
    }
    if(out_h) *out_h=th;
    return 0;
}

size_t jx_thumb_encode(const uint16_t *px,int w,int h,uint8_t *out,size_t cap){
    if(w<=0||h<=0||w>JX_THUMB_MAXW||h>JX_THUMB_MAXH) return 0;
    size_t need=JX_THUMB_HDR+(size_t)w*(size_t)h*2;
    if(cap<need) return 0;
    out[0]='J';out[1]='T';out[2]='H';out[3]='1';
    out[4]=(uint8_t)w; out[5]=(uint8_t)(w>>8); out[6]=(uint8_t)h; out[7]=(uint8_t)(h>>8);
    for(size_t i=0;i<(size_t)w*(size_t)h;i++){
        out[JX_THUMB_HDR+2*i]=(uint8_t)px[i]; out[JX_THUMB_HDR+2*i+1]=(uint8_t)(px[i]>>8);
    }
    return need;
}

int jx_thumb_decode(const uint8_t *b,size_t size,int *w,int *h,const uint8_t **px){
    if(!b||size<JX_THUMB_HDR) return -1;
    if(b[0]!='J'||b[1]!='T'||b[2]!='H'||b[3]!='1') return -1;
    int ww=b[4]|(b[5]<<8), hh=b[6]|(b[7]<<8);
    if(ww<=0||hh<=0||ww>JX_THUMB_MAXW||hh>JX_THUMB_MAXH) return -1;
    if(size!=JX_THUMB_HDR+(size_t)ww*(size_t)hh*2) return -1;
    *w=ww;*h=hh;*px=b+JX_THUMB_HDR; return 0;
}

int jx_thumb_pick_latest(const uint32_t *t,int n){
    int best=-1;
    for(int i=0;i<n;i++) if(t[i]!=0 && (best<0 || t[i]>t[best])) best=i;
    return best;
}
